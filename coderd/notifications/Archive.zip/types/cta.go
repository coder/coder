package types

type TemplateAction struct {
	Label string `json:"label"`
	URL   string `json:"url"`
}
